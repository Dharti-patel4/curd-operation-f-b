import React from 'react'
import Productdata from './Productdata'
import Addproduct from './Addproduct'

const Home = () => {
  return (
    <div>
    <Addproduct/>
    <Productdata/>
      
    </div>
  )
}

export default Home
