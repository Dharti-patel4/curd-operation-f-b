// import Addproduct from "./addproduct";
import React from "react";

import Allroutes from "../allroutes";

const App = () => {
  return (
    <>
      <Allroutes />
    </>
  );
};

export default App;
